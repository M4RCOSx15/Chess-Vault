package com.example.ChessVault.service;

import com.example.ChessVault.entity.Book;
import com.example.ChessVault.exception.ResourceNotFoundException;
import com.example.ChessVault.repository.BookRepository;
import com.example.ChessVault.response.BookResponse;
import com.example.ChessVault.response.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookService {

    private final BookRepository bookRepository;

    public PageResponse<BookResponse> listBooks(int page, int size, String category) {
        var pageable = PageRequest.of(page, size, Sort.by("title"));
        var booksPage = (category != null && !category.isBlank())
                ? bookRepository.findByCategory(category, pageable)
                : bookRepository.findAll(pageable);
        return PageResponse.of(booksPage.map(this::toResponse));
    }

    public BookResponse getBook(UUID id) {
        return bookRepository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Book", id));
    }

    private BookResponse toResponse(Book book) {
        return new BookResponse(
                book.getId(), book.getTitle(), book.getAuthor(),
                book.getCategory(), book.getDescription(),
                book.getExternalLink(), book.getCoverUrl()
        );
    }
}
