package com.example.ChessVault.response;

public record AuthResponse(
        String accessToken,
        String refreshToken,
        String tokenType
) {}
