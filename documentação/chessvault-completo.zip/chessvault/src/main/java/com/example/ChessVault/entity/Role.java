package com.example.ChessVault.entity;

public enum Role {
    USER,
    ADMIN
}
