package com.example.ChessVault.mapper;

import com.example.ChessVault.GameResult;
import com.example.ChessVault.GameTag;
import com.example.ChessVault.PgnContent;
import com.example.ChessVault.entity.Game;
import com.example.ChessVault.response.GameResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.Set;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface GameMapper {

    default GameResponse toResponse(Game game) {
        if (game == null) return null;

        String result = game.getResult() != null ? game.getResult().getNotation() : null;
        String pgnContent = game.getPgn() != null ? game.getPgn().value() : null;
        Set<String> tags = mapTags(game.getTags());

        return new GameResponse(
                game.getId(),
                game.getTitle(),
                game.getWhitePlayer(),
                game.getBlackPlayer(),
                result,
                game.getEvent(),
                game.getGameDate(),
                pgnContent,
                game.getNotes(),
                tags,
                game.getCreatedBy(),
                game.getCreatedAt(),
                game.getUpdatedAt()
        );
    }

    @Named("mapTags")
    default Set<String> mapTags(Set<GameTag> tags) {
        if (tags == null) return Set.of();
        return tags.stream().map(GameTag::name).collect(Collectors.toSet());
    }

    default GameResult mapResult(String notation) {
        if (notation == null) return null;
        return GameResult.fromNotation(notation);
    }

    default PgnContent mapPgn(String pgn) {
        return new PgnContent(pgn);
    }
}
