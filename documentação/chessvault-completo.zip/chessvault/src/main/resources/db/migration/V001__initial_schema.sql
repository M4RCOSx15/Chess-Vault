-- V001__initial_schema.sql
-- Criação inicial do schema Chess Vault

-- Tabela de usuários
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ,
    created_by VARCHAR(255),
    updated_by VARCHAR(255)
);

CREATE INDEX idx_users_email ON users(email);

-- Tabela de refresh tokens
CREATE TABLE refresh_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token VARCHAR(512) NOT NULL UNIQUE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token ON refresh_tokens(token);

-- Tabela de partidas
CREATE TABLE games (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    white_player VARCHAR(100),
    black_player VARCHAR(100),
    result VARCHAR(15),
    event VARCHAR(200),
    game_date DATE,
    pgn_content TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ,
    created_by VARCHAR(255),
    updated_by VARCHAR(255)
);

CREATE INDEX idx_games_user_id ON games(user_id);
CREATE INDEX idx_games_result ON games(result);
CREATE INDEX idx_games_game_date ON games(game_date DESC);
CREATE INDEX idx_games_white_player ON games(white_player);
CREATE INDEX idx_games_black_player ON games(black_player);

-- Tabela de tags de partidas (Many-to-Many)
CREATE TABLE game_tags (
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    tag_name VARCHAR(50) NOT NULL
);

CREATE INDEX idx_game_tags_game_id ON game_tags(game_id);
CREATE INDEX idx_game_tags_name ON game_tags(tag_name);

-- Tabela de livros
CREATE TABLE books (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150),
    category VARCHAR(100),
    description TEXT,
    external_link VARCHAR(500),
    cover_url VARCHAR(500)
);

CREATE INDEX idx_books_category ON books(category);
CREATE INDEX idx_books_title ON books(title);

-- Tabela de vídeos
CREATE TABLE videos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    channel VARCHAR(150),
    description TEXT,
    url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    category VARCHAR(100)
);

CREATE INDEX idx_videos_category ON videos(category);
CREATE INDEX idx_videos_title ON videos(title);
