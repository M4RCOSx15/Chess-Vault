// js/chess-engine.js - Motor de xadrez puro (validação de lances, parser de PGN)
// Extraído do protótipo ChessVault_carlsen.html. Lógica não alterada,
// só isolada num arquivo próprio para reaproveitar na estrutura modular.

// ============================================================
// PARSER DE PGN (linear, sem variantes/comentários)
// ============================================================
function parsePGN(pgn) {
  let s = pgn.replace(/\[.*?\]\s*/g, '');
  s = s.replace(/\{[^}]*\}/g, '');
  s = s.replace(/\$\d+/g, '');

  let prev = '';
  while (prev !== s) { prev = s; s = s.replace(/\([^()]*\)/g, ''); }

  s = s.replace(/\s*(1-0|0-1|1\/2-1\/2|\*)\s*$/, '');

  // Remove os marcadores de número de lance ("1.", "23...", etc).
  // Isso sozinho já ajudaria, mas o problema real é mais profundo:
  // quando o PGN vem sem NENHUM espaço entre lances (ex: "e4e52.Nf3Nc6"),
  // não dá pra confiar em espaço pra separar tokens.
  s = s.replace(/\d+\.+/g, ' ');

  // Em vez de "cortar por espaço", reconhecemos o FORMATO de um lance
  // de xadrez (SAN) diretamente via regex. Isso funciona corretamente
  // mesmo quando não existe espaço nenhum entre um lance e o próximo,
  // porque a regex sabe onde um lance "termina" pela própria gramática
  // do xadrez (ex: sempre acaba numa casa como "e4", "d1", "c8"...).
  const SAN_PATTERN = /O-O-O|O-O|[KQRBN][a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?[+#]?|[a-h]x?[a-h]?[1-8](?:=[QRBN])?[+#]?/g;

  return s.match(SAN_PATTERN) || [];
}

// ============================================================
// MOTOR DE XADREZ
// ============================================================
const VPIECES = {
  wK:'♔', wQ:'♕', wR:'♖', wB:'♗', wN:'♘', wP:'♙',
  bK:'♚', bQ:'♛', bR:'♜', bB:'♝', bN:'♞', bP:'♟'
};

function vInitBoard() {
  return [
    ['bR','bN','bB','bQ','bK','bB','bN','bR'],
    ['bP','bP','bP','bP','bP','bP','bP','bP'],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    ['wP','wP','wP','wP','wP','wP','wP','wP'],
    ['wR','wN','wB','wQ','wK','wB','wN','wR']
  ];
}

function vColor(p) { return p ? p[0] : null; }
function vPT(p)    { return p ? p[1] : null; }
function vIB(r, c) { return r >= 0 && r < 8 && c >= 0 && c < 8; }

let vBoard, vTurn, vCastling, vEnPassant;
let vSelected = null, vLegalMoves = [], vLastMove = [];

function resetViewerEngine() {
  vBoard     = vInitBoard();
  vTurn      = 'w';
  vCastling  = { w: { k: true, q: true }, b: { k: true, q: true } };
  vEnPassant = null;
  vSelected  = null;
  vLegalMoves = [];
  vLastMove   = [];
}

function algebraicToMove(san, board, turn) {
  san = san.replace(/[+#!?]/g, '').trim();
  const t = turn;

  if (san === 'O-O-O' || san === '0-0-0') {
    const r = t === 'w' ? 7 : 0;
    if (board[r][4] === t + 'K' && board[r][0] === t + 'R') return [r, 4, r, 2, null];
    return null;
  }
  if (san === 'O-O' || san === '0-0') {
    const r = t === 'w' ? 7 : 0;
    if (board[r][4] === t + 'K' && board[r][7] === t + 'R') return [r, 4, r, 6, null];
    return null;
  }

  let promo = null;
  const promoMatch = san.match(/=([QRBN])$/i);
  if (promoMatch) {
    promo = t + promoMatch[1].toUpperCase();
    san   = san.replace(/=[QRBN]$/i, '');
  }

  const FILES = 'abcdefgh';
  const RANKS = '87654321';

  let piece = 'P';
  if (/^[KQRBN]/.test(san)) {
    piece = san[0];
    san   = san.slice(1);
  }

  san = san.replace('x', '');

  if (san.length < 2) return null;
  const toFile = san[san.length - 2];
  const toRank = san[san.length - 1];

  if (FILES.indexOf(toFile) === -1 || RANKS.indexOf(toRank) === -1) return null;

  const toC = FILES.indexOf(toFile);
  const toR = RANKS.indexOf(toRank);

  const hint = san.slice(0, san.length - 2);
  let fromFileHint = -1;
  let fromRankHint = -1;

  if (hint.length === 1) {
    if (/[a-h]/.test(hint)) fromFileHint = FILES.indexOf(hint);
    else if (/[1-8]/.test(hint)) fromRankHint = RANKS.indexOf(hint);
  } else if (hint.length === 2) {
    if (/[a-h]/.test(hint[0]) && /[1-8]/.test(hint[1])) {
      fromFileHint = FILES.indexOf(hint[0]);
      fromRankHint = RANKS.indexOf(hint[1]);
    } else if (/[1-8]/.test(hint[0]) && /[a-h]/.test(hint[1])) {
      fromRankHint = RANKS.indexOf(hint[0]);
      fromFileHint = FILES.indexOf(hint[1]);
    }
  }

  const candidates = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p || vColor(p) !== t || vPT(p) !== piece) continue;
      if (fromFileHint >= 0 && c !== fromFileHint) continue;
      if (fromRankHint >= 0 && r !== fromRankHint) continue;
      const legalTargets = vGetLegal(r, c, board, t, vCastling, vEnPassant);
      if (legalTargets.some(([mr, mc]) => mr === toR && mc === toC)) {
        candidates.push([r, c]);
      }
    }
  }

  if (candidates.length === 0) {
    console.warn(`algebraicToMove: nenhum candidato para "${san}" (turn=${t})`);
    return null;
  }

  const [fr, fc] = candidates[0];
  return [fr, fc, toR, toC, promo];
}

function vGetLegal(r, c, board, turn, castling, enPassant) {
  const p = board[r][c];
  if (!p) return [];
  const t = vColor(p);
  if (t !== turn) return [];
  const type = vPT(p);
  const pseudo = [];

  if (type === 'P') {
    const dir = t === 'w' ? -1 : 1;
    const startRow = t === 'w' ? 6 : 1;
    const r1 = r + dir;
    if (vIB(r1, c) && !board[r1][c]) {
      pseudo.push([r1, c]);
      const r2 = r + 2 * dir;
      if (r === startRow && !board[r2][c]) pseudo.push([r2, c]);
    }
    for (const dc of [-1, 1]) {
      const nr = r + dir, nc = c + dc;
      if (!vIB(nr, nc)) continue;
      if (board[nr][nc] && vColor(board[nr][nc]) !== t) pseudo.push([nr, nc]);
      if (enPassant && enPassant[0] === nr && enPassant[1] === nc) pseudo.push([nr, nc]);
    }
  } else if (type === 'N') {
    for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
      const nr = r + dr, nc = c + dc;
      if (vIB(nr, nc) && vColor(board[nr][nc]) !== t) pseudo.push([nr, nc]);
    }
  } else if (type === 'B') {
    _slide(r, c, [[-1,-1],[-1,1],[1,-1],[1,1]], board, t, pseudo);
  } else if (type === 'R') {
    _slide(r, c, [[-1,0],[1,0],[0,-1],[0,1]], board, t, pseudo);
  } else if (type === 'Q') {
    _slide(r, c, [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]], board, t, pseudo);
  } else if (type === 'K') {
    for (const [dr, dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
      const nr = r + dr, nc = c + dc;
      if (vIB(nr, nc) && vColor(board[nr][nc]) !== t) pseudo.push([nr, nc]);
    }
    const row = t === 'w' ? 7 : 0;
    if (r === row && c === 4 && !vIsAttacked(r, c, t === 'w' ? 'b' : 'w', board)) {
      if (castling[t].k &&
          !board[row][5] && !board[row][6] &&
          board[row][7] === t + 'R' &&
          !vIsAttacked(row, 5, t === 'w' ? 'b' : 'w', board) &&
          !vIsAttacked(row, 6, t === 'w' ? 'b' : 'w', board)) {
        pseudo.push([row, 6]);
      }
      if (castling[t].q &&
          !board[row][3] && !board[row][2] && !board[row][1] &&
          board[row][0] === t + 'R' &&
          !vIsAttacked(row, 3, t === 'w' ? 'b' : 'w', board) &&
          !vIsAttacked(row, 2, t === 'w' ? 'b' : 'w', board)) {
        pseudo.push([row, 2]);
      }
    }
  }

  return pseudo.filter(([nr, nc]) => !vWouldCheck(r, c, nr, nc, t, board, enPassant));
}

function _slide(r, c, dirs, board, t, out) {
  for (const [dr, dc] of dirs) {
    let nr = r + dr, nc = c + dc;
    while (vIB(nr, nc)) {
      if (vColor(board[nr][nc]) === t) break;
      out.push([nr, nc]);
      if (board[nr][nc]) break;
      nr += dr; nc += dc;
    }
  }
}

function vWouldCheck(fr, fc, tr, tc, t, board, enPassant) {
  const tmp = board.map(row => [...row]);

  if (vPT(tmp[fr][fc]) === 'P' && enPassant &&
      tr === enPassant[0] && tc === enPassant[1] && !tmp[tr][tc]) {
    const capRow = t === 'w' ? tr + 1 : tr - 1;
    tmp[capRow][tc] = null;
  }

  tmp[tr][tc] = tmp[fr][fc];
  tmp[fr][fc] = null;

  let kr = -1, kc = -1;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (tmp[r][c] === t + 'K') { kr = r; kc = c; break; }
    }
    if (kr !== -1) break;
  }
  if (kr === -1) return true;

  return vIsAttacked(kr, kc, t === 'w' ? 'b' : 'w', tmp);
}

function vIsAttacked(kr, kc, by, b2) {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = b2[r][c];
      if (!p || vColor(p) !== by) continue;
      const type = vPT(p);

      if (type === 'P') {
        const dir = by === 'w' ? -1 : 1;
        if (r + dir === kr && Math.abs(c - kc) === 1) return true;
        continue;
      }
      if (type === 'N') {
        const dr = Math.abs(r - kr), dc = Math.abs(c - kc);
        if ((dr === 2 && dc === 1) || (dr === 1 && dc === 2)) return true;
        continue;
      }
      if (type === 'K') {
        if (Math.abs(r - kr) <= 1 && Math.abs(c - kc) <= 1) return true;
        continue;
      }
      const isDiag = (kr - r) !== 0 && Math.abs(kr - r) === Math.abs(kc - c);
      const isStraight = (r === kr) || (c === kc);

      if ((type === 'B' || type === 'Q') && isDiag) {
        const dr = Math.sign(kr - r), dc = Math.sign(kc - c);
        let nr = r + dr, nc = c + dc;
        while (vIB(nr, nc) && !(nr === kr && nc === kc)) {
          if (b2[nr][nc]) { nr = -1; break; }
          nr += dr; nc += dc;
        }
        if (nr === kr) return true;
      }
      if ((type === 'R' || type === 'Q') && isStraight) {
        const dr = Math.sign(kr - r), dc = Math.sign(kc - c);
        let nr = r + dr, nc = c + dc;
        while (vIB(nr, nc) && !(nr === kr && nc === kc)) {
          if (b2[nr][nc]) { nr = -1; break; }
          nr += dr; nc += dc;
        }
        if (nr === kr) return true;
      }
    }
  }
  return false;
}

function vApplyMove(fr, fc, tr, tc, promo) {
  const p = vBoard[fr][fc];
  if (!p) return;
  const t = vColor(p);
  const type = vPT(p);

  if (type === 'P' && vEnPassant &&
      tr === vEnPassant[0] && tc === vEnPassant[1] && !vBoard[tr][tc]) {
    const capRow = t === 'w' ? tr + 1 : tr - 1;
    vBoard[capRow][tc] = null;
  }

  vBoard[tr][tc] = p;
  vBoard[fr][fc] = null;

  if (type === 'P' && Math.abs(tr - fr) === 2) {
    vEnPassant = [(fr + tr) / 2, tc];
  } else {
    vEnPassant = null;
  }

  if (type === 'K') {
    vCastling[t].k = false;
    vCastling[t].q = false;
    const row = t === 'w' ? 7 : 0;
    if (tc === 6 && fc === 4) { vBoard[row][5] = vBoard[row][7]; vBoard[row][7] = null; }
    if (tc === 2 && fc === 4) { vBoard[row][3] = vBoard[row][0]; vBoard[row][0] = null; }
  }

  if (type === 'R') {
    if (fc === 0) vCastling[t].q = false;
    if (fc === 7) vCastling[t].k = false;
  }
  const opp = t === 'w' ? 'b' : 'w';
  const oppRow = opp === 'w' ? 7 : 0;
  if (tr === oppRow && tc === 0) vCastling[opp].q = false;
  if (tr === oppRow && tc === 7) vCastling[opp].k = false;

  if (type === 'P' && (tr === 0 || tr === 7)) {
    vBoard[tr][tc] = promo || (t + 'Q');
  }

  vLastMove = [[fr, fc], [tr, tc]];
  vTurn = t === 'w' ? 'b' : 'w';
}
